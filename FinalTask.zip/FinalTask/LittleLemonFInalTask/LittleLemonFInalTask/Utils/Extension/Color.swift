//
//  Color.swift
//  LittleLemonFInalTask
//
//  Created by Amed on 5/25/24.
//

import Foundation
import SwiftUI

extension Color {
    static let appPrimary = Color(red: 73/255, green: 94/255, blue: 87/255)
    static let appAccent = Color(red: 244/255, green: 206/255, blue: 20/255)
    static let appGray = Color(red: 237/255, green: 239/255, blue: 238/255)
}
