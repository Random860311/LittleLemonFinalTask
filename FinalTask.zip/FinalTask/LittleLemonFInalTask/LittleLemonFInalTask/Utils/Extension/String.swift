//
//  String.swift
//  LittleLemonDiners
//
//  Created by Amed on 4/8/24.
//

import Foundation

extension String {
    var uppercaseFirst: String { prefix(1).uppercased() + dropFirst() }
    var lowercaseFirst: String { prefix(1).lowercased() + dropFirst() }
    
    var isValidEmail: Bool {
        let emailRegEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}"

        let emailPred = NSPredicate(format:"SELF MATCHES %@", emailRegEx)
        return emailPred.evaluate(with: self)
        
    }
}
