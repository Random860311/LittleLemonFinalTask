//
//  Navigation.swift
//  LittleLemonRestaurant
//
//  Created by Amed on 4/7/24.
//

import Foundation
enum Routes {   
    case loginScreen
    case onboardingScreen
    case homeScreen
    case profileScreen
}
