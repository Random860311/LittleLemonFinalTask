//
//  Core.swift
//  LittleLemonRestaurant
//
//  Created by Amed on 4/6/24.
//

import Foundation
struct Core {
    static let serviceLocator: ServiceLocator = BasicServiceLocator.shared
}

