//
//  BasicServiceLocator.swift
//  LittleLemonRestaurant
//
//  Created by Amed on 4/6/24.
//

import Foundation
import SwiftUI

final class BasicServiceLocator: ServiceLocator {
    static let shared: ServiceLocator = {
        let instance = BasicServiceLocator()
        let managedContext = PersistenceController.shared.container.viewContext
        
        let unitOfWork = UnitOfWork(context: managedContext)
        
        instance.addService(type: UnitOfWork.self, service: unitOfWork)
        
        instance.addService(type: UserService.self, service: UserServiceImp(unitOfWork: unitOfWork))
        instance.addService(type: DishService.self, service: DishServiceImp(unitOfWork: unitOfWork))
        instance.addService(type: RestaurantService.self, service: RestaurantServiceMock())

        
        return instance
    }()
    
    private var reg: Dictionary<String, Any> = [:]
    
    private init() {}
    
    private func typeName(some: Any) -> String {
        return (some is Any.Type) ? "\(some)" : "\(type(of: some))"
    }
    
    private func addService<T>(type: T.Type, service: T) {
        let key = typeName(some: type)
        reg[key] = service
    }
    
    func getService<T>(type: T.Type) -> T? {
        let key = typeName(some: type)
        return reg[key] as? T
    }
}
