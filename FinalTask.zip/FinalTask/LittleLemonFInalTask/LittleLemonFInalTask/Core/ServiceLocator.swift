//
//  ServiceLocator.swift
//  LittleLemonRestaurant
//
//  Created by Amed on 4/6/24.
//

import Foundation
protocol ServiceLocator {
    func getService<T>(type: T.Type) -> T?
}


