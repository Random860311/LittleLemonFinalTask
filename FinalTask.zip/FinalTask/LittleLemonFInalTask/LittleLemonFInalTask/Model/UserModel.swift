//
//  MenuItem.swift
//  LittleLemonDiners
//
//  Created by Amed on 4/8/24.
//

import Foundation

struct UserModel: Identifiable {
    var id = UUID()
    var name: String
    var lastName: String
    var email: String
    var password: String
    var phoneNumber: String
    var logged = false
    var emailConfig: UserEmailConfig
    
    init() {
        self.init(name: "", lastName: "", password: "", email: "")
    }
    
    init(
        name: String,
        lastName: String,
        password: String,
        email: String,
        id: UUID = UUID(),
        logged: Bool = false,
        phoneNumber: String = "",
        emailConfig: UserEmailConfig = UserEmailConfig()
    ) {
        self.id = id
        self.name = name
        self.lastName = lastName
        self.email = email
        self.password = password
        self.logged = logged
        self.emailConfig = emailConfig
        self.phoneNumber = phoneNumber
    }
}

struct UserEmailConfig {
    var orderStatus = false
    var passwordChanges = false
    var specialOffers = false
    var newsletter = false
}
