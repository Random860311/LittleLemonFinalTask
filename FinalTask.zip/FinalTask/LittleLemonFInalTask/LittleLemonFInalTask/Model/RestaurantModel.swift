//
//  RestaurantModel.swift
//  LittleLemonFInalTask
//
//  Created by Amed on 5/25/24.
//

import Foundation
struct RestaurantModel: Identifiable{
    let id: UUID
    let name: String
    let info: String
    let city: String
    let image: String
    
}
