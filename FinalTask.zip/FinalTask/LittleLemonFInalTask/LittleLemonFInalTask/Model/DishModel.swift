//
//  DishModel.swift
//  LittleLemonFInalTask
//
//  Created by Amed on 5/25/24.
//

import Foundation

struct DishModel: Identifiable {
    let id: UUID
    let name: String
    let info: String
    let category: String
    let price: Double
    let img: String
}
