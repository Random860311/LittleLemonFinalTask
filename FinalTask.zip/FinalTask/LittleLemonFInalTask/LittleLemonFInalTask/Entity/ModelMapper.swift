//
//  DomainModel.swift
//  EntitiesContextRelationships
//
//  Created by Amed on 4/13/24.
//

import Foundation
protocol ModelMapper {
    associatedtype ModelType
    
    func toModel() -> ModelType
    func from(model: ModelType)
}
