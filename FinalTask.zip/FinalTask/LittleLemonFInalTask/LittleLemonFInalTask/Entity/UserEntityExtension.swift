//
//  Customer.swift
//  EntitiesContextRelationships
//
//  Created by Amed on 4/13/24.
//

import Foundation


extension UserEntity: ModelMapper {
    func toModel() -> UserModel {
        return UserModel(
            name: self.name,
            lastName: self.lastName,
            password: self.password,
            email: self.email,
            id: self.id,
            logged: self.logged,
            phoneNumber: self.phone,
            emailConfig: UserEmailConfig(
                orderStatus: self.orderStatus,
                passwordChanges: self.passwordChanges,
                specialOffers: self.specialOffers,
                newsletter: self.newsletter
            )
        )
    }
    
    func from(model: UserModel) {
        self.id = model.id
        self.name = model.name
        self.lastName = model.lastName
        self.password = model.password
        self.email = model.email
        self.logged = model.logged
        self.orderStatus = model.emailConfig.orderStatus
        self.passwordChanges = model.emailConfig.passwordChanges
        self.specialOffers = model.emailConfig.specialOffers
        self.newsletter = model.emailConfig.newsletter
        self.phone = model.phoneNumber
    }
}

