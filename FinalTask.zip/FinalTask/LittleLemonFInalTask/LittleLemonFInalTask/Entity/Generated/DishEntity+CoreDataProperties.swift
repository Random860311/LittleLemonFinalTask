//
//  DishEntity+CoreDataProperties.swift
//  LittleLemonFInalTask
//
//  Created by Amed on 5/25/24.
//
//

import Foundation
import CoreData


extension DishEntity {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<DishEntity> {
        return NSFetchRequest<DishEntity>(entityName: "DishEntity")
    }

    @NSManaged public var id: UUID
    @NSManaged public var category: String
    @NSManaged public var name: String
    @NSManaged public var info: String
    @NSManaged public var price: Double
    @NSManaged public var image: String

}

extension DishEntity : Identifiable {

}
