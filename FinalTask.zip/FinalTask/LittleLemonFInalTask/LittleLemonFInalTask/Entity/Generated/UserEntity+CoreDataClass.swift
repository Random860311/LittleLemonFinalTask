//
//  UserEntity+CoreDataClass.swift
//  LittleLemonFInalTask
//
//  Created by Amed on 5/28/24.
//
//

import Foundation
import CoreData

@objc(UserEntity)
public class UserEntity: NSManagedObject {

}
