//
//  DishEntity+CoreDataClass.swift
//  LittleLemonFInalTask
//
//  Created by Amed on 5/25/24.
//
//

import Foundation
import CoreData

@objc(DishEntity)
public class DishEntity: NSManagedObject {

}
