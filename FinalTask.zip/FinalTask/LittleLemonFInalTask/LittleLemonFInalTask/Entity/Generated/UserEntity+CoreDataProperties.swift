//
//  UserEntity+CoreDataProperties.swift
//  LittleLemonFInalTask
//
//  Created by Amed on 5/28/24.
//
//

import Foundation
import CoreData


extension UserEntity {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<UserEntity> {
        return NSFetchRequest<UserEntity>(entityName: "UserEntity")
    }

    @NSManaged public var avatarImage: String?
    @NSManaged public var email: String
    @NSManaged public var id: UUID
    @NSManaged public var lastName: String
    @NSManaged public var logged: Bool
    @NSManaged public var name: String
    @NSManaged public var newsletter: Bool
    @NSManaged public var orderStatus: Bool
    @NSManaged public var password: String
    @NSManaged public var passwordChanges: Bool
    @NSManaged public var specialOffers: Bool
    @NSManaged public var phone: String

}

extension UserEntity : Identifiable {

}
