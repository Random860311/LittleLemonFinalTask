//
//  DishEntityExtension.swift
//  LittleLemonFInalTask
//
//  Created by Amed on 5/25/24.
//

import Foundation

extension DishEntity: ModelMapper {
    func toModel() -> DishModel {
        return DishModel(
            id: self.id,
            name: self.name,
            info: self.info, 
            category: self.category,
            price: self.price,
            img: self.image
        )
    }
    
    func from(model: DishModel) {
        self.id = model.id
        self.name = model.name
        self.info = model.info
        self.category = model.category
        self.price = model.price
        self.image = model.img
    }
}
