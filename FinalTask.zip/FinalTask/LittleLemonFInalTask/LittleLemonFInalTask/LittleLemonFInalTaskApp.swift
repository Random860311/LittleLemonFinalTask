//
//  LittleLemonFInalTaskApp.swift
//  LittleLemonFInalTask
//
//  Created by Amed on 5/19/24.
//

import SwiftUI

@main
struct LittleLemonFInalTaskApp: App {
    let persistenceController = PersistenceController.shared 

    var body: some Scene {
        WindowGroup {
            MainScreen()
                .environment(\.managedObjectContext, persistenceController.container.viewContext)
        }
    }
}
