//
//  HeroView.swift
//  LittleLemonFInalTask
//
//  Created by Amed on 5/25/24.
//

import SwiftUI

struct HeroView: View {
    @Binding var restaurantModel: RestaurantModel

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text(restaurantModel.name)
                .foregroundStyle(Color.appAccent)
                .font(.largeTitle)
                .bold()
            
            HStack(spacing: 20) {
                VStack(alignment: .leading, spacing: 20) {
                    Text(restaurantModel.city)
                        .foregroundStyle(Color.appGray)
                        .font(.title)
                    
                    Text(restaurantModel.info)
                        .foregroundStyle(Color.appGray)
                }
                
                Image(restaurantModel.image)
                    .resizable()
                    .scaledToFit()
                    .background(content: {
                        Image(systemName: "person")
                            .resizable()
                            .scaledToFit()
                    })
                    .mask(RoundedRectangle(cornerRadius: 25))
                    .frame(width: 140, height: 140)
            }
        }
        .padding()
        .background(Color.appPrimary)
    }
}

#if DEBUG
    struct HeroViewPreview: PreviewProvider {
        @State static var model = RestaurantModel(
            id: UUID(),
            name: "Little Lemon",
            info: "We are a family owned Mediterranean restaurant, focused on tradicional recipes served with a modern twist.",
            city: "Chicago",
            image: ""
        )

        static var previews: some View {
            HeroView(restaurantModel: $model)
        }
    }
#endif
