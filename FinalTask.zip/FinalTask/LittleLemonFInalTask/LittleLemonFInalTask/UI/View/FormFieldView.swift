//
//  FormFieldView.swift
//  LittleLemonFInalTask
//
//  Created by Amed on 5/21/24.
//

import SwiftUI

struct FormFieldView: View {
    @State var label: String
    @State var keyBoardType: UIKeyboardType = .default

    @Binding var textValue: String
    @Binding var textError: String

    var validationCallback: () -> Void

    var body: some View {
        VStack(alignment: .leading) {
            Text(label).font(.subheadline)
            TextField("", text: $textValue, onEditingChanged: { changed in
                if changed {
                    textError = ""
                } else {
                    validationCallback()
                }
            })
            .keyboardType(keyBoardType)
            .textFieldStyle(.roundedBorder)
            .padding(.bottom, textError.isEmpty ? 10.0 : 0.0)

            if !textError.isEmpty {
                Text(textError)
                    .font(.footnote)
                    .foregroundStyle(.red)
                    .padding(.bottom)
            }
        }
    }
}

// #Preview {
#if DEBUG
    struct FormViewPreview: PreviewProvider {
        @State static var label = "Label"
        @State static var value = ""
        @State static var textError = ""

        static var previews: some View {
            FormFieldView(label: label, textValue: $value, textError: $textError, validationCallback: {
            })
        }
    }
#endif
// }
