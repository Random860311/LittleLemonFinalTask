//
//  FormPasswordView.swift
//  LittleLemonFInalTask
//
//  Created by Amed on 5/21/24.
//

import SwiftUI

struct FormPasswordView: View {
    @State var label: String

    @Binding var textValue: String
    @Binding var textError: String

    
    var body: some View {
        VStack(alignment: .leading) {
            Text(label).font(.subheadline)
            SecureField("", text: $textValue)
            .textFieldStyle(.roundedBorder)
            .padding(.bottom, textError.isEmpty ? 10.0 : 0.0)

            if !textError.isEmpty {
                Text(textError)
                    .font(.footnote)
                    .foregroundStyle(.red)
                    .padding(.bottom)
            }
        }
    }
}

#if DEBUG
    struct FormPasswordPreview: PreviewProvider {
        @State static var label = "Label"
        @State static var value = ""
        @State static var textError = ""

        static var previews: some View {
            FormPasswordView(label: label, textValue: $value, textError: $textError)
        }
    }
#endif
