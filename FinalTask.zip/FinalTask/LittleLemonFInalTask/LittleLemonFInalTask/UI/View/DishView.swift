//
//  DishView.swift
//  LittleLemonFInalTask
//
//  Created by Amed on 5/26/24.
//

import SwiftUI

struct DishView: View {
    @Environment(\.locale) private var locale
    
    @Binding var dish: DishModel
    
    var body: some View {
        VStack(alignment: .leading) {
            Text(dish.name).bold()
            HStack {
                VStack(alignment: .leading) {
                    Text(dish.info)
                        .foregroundStyle(Color.gray)
                        .lineLimit(2)
                        .padding(.bottom, 10)
                        //.frame(maxWidth: .infinity)

                    Text(dish.price, format: .currency(code: locale.currency?.identifier ?? "USD"))
                        .foregroundStyle(Color.gray)
                        .bold()
                }
                //.frame(maxWidth: .infinity)
                if !dish.img.isEmpty {
                    Image(dish.img)
                        .resizable()
                        .scaledToFit()
                        .frame(width: 110, height: 110)
                }
            }
        }
    }
}

#if DEBUG
    struct DishViewPreview: PreviewProvider {
        @State static var dish = DishModel(
            id: UUID(),
            name: "Beef Wellington tart",
            info: "This easy new twist on the continental dish, beef Wellington, turns the classic roulade shape into a tart. You can prep the flaky pastry weeks in advance, if you need to, and pop it out of the freezer to cook ahead of a dinner party!",
            category: "Starters",
            price: 21.20,
            img: "beef-wellington-tart-173822-1"
        )
        
        static var previews: some View {
            DishView(dish: $dish)
        }
    }
#endif

