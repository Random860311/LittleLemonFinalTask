//
//  HeaderView.swift
//  LittleLemonFInalTask
//
//  Created by Amed on 5/24/24.
//

import SwiftUI

struct HeaderView: View {
    @Binding var userImagePath: String
    @Binding var navPath: NavigationPath
    @State var enableNavigation = true
    
    var body: some View {
        HStack {
            Image("LogoHorizontal")
                .resizable()
                .scaledToFit()
                .frame(maxWidth: 200)
                .padding(.leading, 70)
            
            Button(action: {
                if enableNavigation {
                    navPath.append(Routes.profileScreen)
                }                
            }, label: {
                Image(userImagePath)
                    .resizable()
                    .scaledToFit()
                    .background(content: {
                        Image(systemName: "person")
                            .resizable()
                            .scaledToFit()
                    })
                    .mask(Circle())
                    .frame(width: 50, height: 50)
                    .padding(.trailing, 20)
            })
            
        }
        .frame(height: 50)
    }
}
#if DEBUG
    struct HeaderViewPreview: PreviewProvider {
        @State static var imgPath = ""
        @State static var navPath = NavigationPath()

        static var previews: some View {
            HeaderView(userImagePath: $imgPath, navPath: $navPath)
        }
    }
#endif

