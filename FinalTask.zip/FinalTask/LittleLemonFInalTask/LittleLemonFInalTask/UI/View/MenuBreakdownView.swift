//
//  MenuBreakdownView.swift
//  LittleLemonFInalTask
//
//  Created by Amed on 5/26/24.
//

import SwiftUI

struct MenuBreakdownView: View {
    @Binding var categories: [String]
    @Binding var selectedCategory: String
    
    var body: some View {
        VStack(alignment: .leading) {
            Text("ORDER FOR DELIVERY!")
                .bold()
            
            ScrollView(.horizontal) {
                HStack(spacing: 10) {
                    ForEach(categories, id: \.self) { category in
                        Button(action: {
                            selectedCategory = category
                        }, label: {
                            Text(category)
                                .bold()
                                .foregroundStyle(Color.appPrimary)
                        })
                        .padding(10)
                        .background(selectedCategory == category ? Color.appAccent : Color.appGray)
                        .cornerRadius(15)
                        
                    }
                }
                
            }
        }
        
    }
}

#if DEBUG
    struct MenuBreakdownViewPreview: PreviewProvider {
        @State static var categories = [
            "Starters",
            "Mains",
            "Deserts",
            "Drinks"
        ]
        @State static var selectedCategory: String = categories.first!

        static var previews: some View {
            MenuBreakdownView(categories: $categories, selectedCategory: $selectedCategory)
        }
    }
#endif

