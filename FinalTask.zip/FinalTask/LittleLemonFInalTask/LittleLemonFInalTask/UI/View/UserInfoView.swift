//
//  UserInfoView.swift
//  LittleLemonFInalTask
//
//  Created by Amed on 5/20/24.
//

import SwiftUI

struct UserInfoView: View {
    @StateObject var viewModel: UserInfoViewModel
    
    @State var showPasswordFields: Bool
    @State var showOldPassword: Bool
    
    var body: some View {
        VStack (alignment: .leading){
            FormFieldView(label: "First name*", textValue: $viewModel.name, textError: $viewModel.nameError, validationCallback: viewModel.validateName)
            
            FormFieldView(label: "Last name*", textValue: $viewModel.lastName, textError: $viewModel.lastNameError, validationCallback: viewModel.validateLastName)
            
            FormFieldView(label: "Email*", textValue: $viewModel.email, textError: $viewModel.emailError, validationCallback: viewModel.validateEmail)
            
            if(showPasswordFields) {
                VStack {
                    if(showOldPassword) {
                        FormPasswordView(
                            label: "Old password*",
                            textValue: $viewModel.oldPassword,
                            textError: $viewModel.oldPasswordError
                        )
                    }
                    
                    FormPasswordView(
                        label: "Password*",
                        textValue: $viewModel.newPassword,
                        textError: $viewModel.newPasswordError
                    )
                    
                    FormPasswordView(
                        label: "Confirm new password*",
                        textValue: $viewModel.confirmNewPassword,
                        textError: $viewModel.confirmNewPasswordError
                    )
                }
            }
            
            FormFieldView(label: "Phone number*", textValue: $viewModel.phoneNumber, textError: $viewModel.phoneNumberError, validationCallback: viewModel.validatePhoneNumber)
        }
        
        
    }
}

#Preview {
    UserInfoView(viewModel: UserInfoViewModel(), showPasswordFields: true, showOldPassword: true)
}
