//
//  OnboardingScreen.swift
//  LittleLemonFInalTask
//
//  Created by Amed on 5/19/24.
//

import SwiftUI

struct OnboardingScreen: View {
    @Environment(\.presentationMode) var presentationMode
    
    @StateObject private var viewModel = OnBoardingViewModel()
    
    var body: some View {
        VStack {
            Image("LogoHorizontal")
                .resizable()
                .scaledToFit()
                .frame(maxWidth: 200)
            
            HeroView(restaurantModel: $viewModel.restaurant)
            
            ScrollView {
                VStack {

                    UserInfoView(viewModel: viewModel.userInfoViewModel, showPasswordFields: true, showOldPassword: false)
                    
                    Button {
                        Task {
                            let registered = await viewModel.register(checkOldPassword: false)
                            if(registered) {
                                presentationMode.wrappedValue.dismiss()
                            }
                        }
                    } label: {
                        Text("Register")
                    }
                }
                .padding()
            }
        }
        .task {
            await viewModel.loadRestaurantInfo()
        }
    }
}

#Preview {
    OnboardingScreen()
}
