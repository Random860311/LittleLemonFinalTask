//
//  LoginScreen.swift
//  LittleLemonFInalTask
//
//  Created by Amed on 5/21/24.
//

import SwiftUI

struct LoginScreen: View {
    @Environment(\.presentationMode) var presentationMode
    
    @StateObject private var viewModel = LoginViewModel()
    @State private var loginActive = false
    
    @Binding var navPath: NavigationPath
    @Binding var logged: Bool
    
    var body: some View {
        ScrollView {
            VStack {
                Image("LogoHorizontal")
                    .resizable()
                    .scaledToFit()
                    .frame(maxWidth: 200)
                
                FormFieldView(
                    label: "Email*",
                    keyBoardType: .emailAddress,
                    textValue: $viewModel.email,
                    textError: $viewModel.emailError,
                    validationCallback: { viewModel.validateEmail() }
                )
                
                FormPasswordView(
                    label: "Password*",
                    textValue: $viewModel.password,
                    textError: $viewModel.passwordError
                )
                
                HStack {
                    Button{
                        Task {
                            logged = await viewModel.login()
                            print("login action: \(logged)")
                            if(logged) {
                                presentationMode.wrappedValue.dismiss()
                            }
                        }
                    } label: { Text("Login") }
                    
                    Button{
                        navPath.append(Routes.onboardingScreen)
                    } label: { Text("Register") }
                }
            }
            .padding()
        }
    }
}

#if DEBUG
    struct LoginScreenPreview: PreviewProvider {
        @State static var navPath = NavigationPath()
        @State static var logged = false
        
        static var previews: some View {
            LoginScreen(navPath: $navPath, logged: $logged)
        }
    }
#endif

