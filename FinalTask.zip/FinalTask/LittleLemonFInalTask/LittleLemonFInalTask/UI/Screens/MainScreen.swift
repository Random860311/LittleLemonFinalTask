//
//  SplashScreen.swift
//  LittleLemonFInalTask
//
//  Created by Amed on 5/20/24.
//

import SwiftUI

struct MainScreen: View {
    @State var navPath = NavigationPath()
    
    @StateObject private var viewModel = MainViewModel()

    
    var body: some View {
        NavigationStack(path: $navPath) {
            VStack {
                if viewModel.loading {
                    VStack {
                        Text("Main Screen")
                    }
                }
                else {
                    if viewModel.logged {
                        HomeScreen(navPath: $navPath)
                    }
                    else {
                        LoginScreen(navPath: $navPath, logged: $viewModel.logged)
                    }
                }
                
            }
            .task {
                await viewModel.isUserLogged()
            }
            .navigationDestination(for: Routes.self) { route in
                switch route {
                case Routes.loginScreen:
                    LoginScreen(navPath: $navPath, logged: $viewModel.logged)
                case Routes.onboardingScreen:
                    OnboardingScreen()
                case Routes.homeScreen:
                    HomeScreen(navPath: $navPath)
                case Routes.profileScreen:
                    ProfileScreen(navPath: $navPath)
                }
            }
            
        }
        
    }
}

#Preview {
    MainScreen()
}
