//
//  HomeScreen.swift
//  LittleLemonFInalTask
//
//  Created by Amed on 5/19/24.
//

import SwiftUI

struct HomeScreen: View {
    @StateObject private var viewModel = HomeViewModel()
    @Binding var navPath: NavigationPath
    
    var body: some View {
        VStack {
            HeaderView(userImagePath: $viewModel.user.name, navPath: $navPath)
            HeroView(restaurantModel: $viewModel.restaurant)
            MenuBreakdownView(categories: $viewModel.categories, selectedCategory: $viewModel.selectedCategory)
                .padding()
            
            List {
                ForEach($viewModel.dishes) { dish in
                    DishView(dish: dish)
                }
            }
            .listStyle(PlainListStyle())
        }.task {
            await viewModel.loadLoggedUser()
            await viewModel.loadRestaurantInfo()
            await viewModel.loadDishInfo()
        }
        
    }
}

#if DEBUG
    struct HomeScreenPreview: PreviewProvider {
        @State static var navPath = NavigationPath()

        static var previews: some View {
            HomeScreen(navPath: $navPath)
        }
    }
#endif

