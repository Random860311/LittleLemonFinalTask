//
//  ProfileScreen.swift
//  LittleLemonFInalTask
//
//  Created by Amed on 5/19/24.
//

import SwiftUI

struct ProfileScreen: View {
    @Environment(\.presentationMode) var presentationMode
    
    @StateObject private var viewModel = ProfileViewModel()
    
    @Binding var navPath: NavigationPath

    var body: some View {
        VStack(alignment: .leading) {
            
            HeaderView(userImagePath: $viewModel.userInfoViewModel.name, navPath: $navPath, enableNavigation: false)
            
            ScrollView {
                VStack(alignment: .leading) {
                    Text("Personal information")
                        .bold()
                        .padding(.bottom)
                    
                    Text("Avatar")
                    
                    HStack(spacing: 25) {
                        Image(viewModel.userInfoViewModel.name)
                            .resizable()
                            .scaledToFit()
                            .background(content: {
                                Image(systemName: "person")
                                    .resizable()
                                    .scaledToFit()
                            })
                            .mask(Circle())
                            .frame(width: 70, height: 70)
                        
                        Button(
                            action: {
                                print("Change image")
                            }, 
                            label: {
                                Text("Change")
                                    .bold()
                                    .foregroundStyle(Color.appGray)
                            })
                            .padding(12)
                            .background(Color.appPrimary)
                            .cornerRadius(10)

                        Button(
                            action: {
                                print("Remove image")
                            }, 
                            label: {
                                Text("Remove")
                                    .foregroundStyle(Color.appPrimary)
                            })
                            .padding(12)
                            .border(Color.appPrimary)
                    }
                    .padding(.bottom)
                    
                    UserInfoView(viewModel: viewModel.userInfoViewModel, showPasswordFields: true, showOldPassword: true)
                        .padding(.bottom)
                    
                    Text("Email notifications")
                        .bold()
                        .padding(.bottom)
                    
                    Toggle(isOn: $viewModel.configOrderStatus, label: {
                        Text("Order statuses")
                    })
                    .padding(.bottom, 5)
                    
                    Toggle(isOn: $viewModel.configPasswordChanges, label: {
                        Text("Password changes")
                    })
                    .padding(.bottom, 5)
                    
                    Toggle(isOn: $viewModel.configSpecialOffers, label: {
                        Text("Special offers")
                    })
                    .padding(.bottom, 5)
                    
                    Toggle(isOn: $viewModel.configNewsletter, label: {
                        Text("Newsletter")
                    })
                    .padding(.bottom)
                    
                    Button(
                        action: {
                            Task {
                                _ = await viewModel.logOut()
                                presentationMode.wrappedValue.dismiss()
                            }
                        },
                        label: {
                            Text("Log out")
                                .foregroundStyle(Color.black)
                                .frame(maxWidth: .infinity)
                        })
                        .padding(12)
                        .background(
                            RoundedRectangle(cornerRadius: 10)
                                .fill(Color.appAccent)
                        )
                        .overlay{
                            RoundedRectangle(cornerRadius: 10)
                                .stroke(.black)
                        }
                        .padding(.bottom)
                    
                    HStack {
                        Button(
                            action: {
                                presentationMode.wrappedValue.dismiss()
                            }, 
                            label: {
                                Text("Discard changes")
                                    .foregroundStyle(Color.appPrimary)
                            })
                            .padding(12)
                            .background(
                                RoundedRectangle(cornerRadius: 10)
                                    .fill(Color.white)
                            )
                            .overlay{
                                RoundedRectangle(cornerRadius: 10)
                                    .stroke(.black)
                            }
                        
                        Spacer()
                        
                        Button(
                            action: {
                                Task {
                                    let result = await viewModel.saveChanges()
                                    print("changes: \(result)")
                                    presentationMode.wrappedValue.dismiss()
                                }
                            },
                            label: {
                                Text("Save changes")
                                    .bold()
                                    .foregroundStyle(Color.appGray)
                            })
                            .padding(12)
                            .background(Color.appPrimary)
                            .cornerRadius(10)
                    }
                        
                }
                .padding()
                .background(
                    RoundedRectangle(cornerRadius: 10)
                        .fill(Color.white)
                )
                .overlay{
                    RoundedRectangle(cornerRadius: 10)
                        .stroke(Color.gray, lineWidth: 0.4)
                        
                }
                .padding()
                .task {
                    await viewModel.loadLoggedUser()
                }
            }
            
        }
    }
}

#if DEBUG
    struct ProfileScreenPreview: PreviewProvider {
        @State static var navPath = NavigationPath()

        static var previews: some View {
            ProfileScreen(navPath: $navPath)
        }
    }
#endif
