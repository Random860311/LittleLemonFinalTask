//
//  HomeViewModel.swift
//  LittleLemonFInalTask
//
//  Created by Amed on 5/24/24.
//

import Foundation

@MainActor
final class HomeViewModel: ObservableObject {
    @Published var user = UserModel()
    @Published var restaurant = RestaurantModel(id: UUID(), name: "", info: "", city: "", image: "")
    @Published var categories = [String]()
    @Published var selectedCategory = "" {
        didSet {
            Task {
                await loadDishes()
            }
        }
    }
    @Published var dishes = [DishModel]()
    
    private let userService: UserService
    private let restaurantService: RestaurantService
    private let dishService: DishService
    
    init() {
        self.userService = Core.serviceLocator.getService(type: UserService.self)!
        self.restaurantService = Core.serviceLocator.getService(type: RestaurantService.self)!
        self.dishService = Core.serviceLocator.getService(type: DishService.self)!
    }
    
    func loadLoggedUser() async {
        do {
            guard let user = try userService.getUserLogged() else {
                print("No user logged")
                return
            }
            self.user = user
        }
        catch(let error) {
            print(error)
        }
    }
    
    func loadRestaurantInfo() async {
        restaurant = restaurantService.getRestaurantData()
    }
    
    func loadDishes() async {
        do {
            dishes = try dishService.getAll(category: selectedCategory)
        }
        catch(let error) {
            print(error)
        }
    }
    
    func loadDishInfo () async {
        do {
            try dishService.insertDummyData()
            categories = try dishService.getAllCategories().sorted()
            if let first = categories.first {
                selectedCategory = first
            }
            await loadDishes()
            
        }
        catch(let error) {
            print(error)
        }
    }
}
