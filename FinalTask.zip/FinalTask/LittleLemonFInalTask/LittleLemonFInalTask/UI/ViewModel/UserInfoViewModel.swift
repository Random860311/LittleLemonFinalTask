//
//  UserInfoViewModel.swift
//  LittleLemonFInalTask
//
//  Created by Amed on 5/20/24.
//

import Foundation

final class UserInfoViewModel: ObservableObject {
    @Published var name: String
    @Published var lastName: String
    @Published var email: String
    @Published var phoneNumber: String
    @Published var oldPassword: String {
        didSet {
            validateOldPassword()
        }
    }
    @Published var newPassword: String {
        didSet {
            validateNewPassword()
        }
    }
    @Published var confirmNewPassword: String {
        didSet {
            validateConfirmNewPassword()
        }
    }
    
    @Published var nameError: String
    @Published var lastNameError: String
    @Published var emailError: String
    @Published var phoneNumberError: String
    @Published var oldPasswordError: String
    @Published var newPasswordError: String
    @Published var confirmNewPasswordError: String
    
    private let userService: UserService
    
    convenience init() {
        self.init(name: "", lastName: "", email: "", phoneNumber: "", oldPassword: "", newPassword: "", confirmNewPassword: "")
    }
    
    init(name: String, lastName: String, email: String, phoneNumber: String, oldPassword: String, newPassword: String, confirmNewPassword: String) {
        self.name = name
        self.lastName = lastName
        self.email = email
        self.phoneNumber = phoneNumber
        self.oldPassword = oldPassword
        self.newPassword = newPassword
        self.confirmNewPassword = confirmNewPassword
        
        self.nameError = ""
        self.lastNameError = ""
        self.emailError = ""
        self.phoneNumberError = ""
        self.oldPasswordError = ""
        self.newPasswordError = ""
        self.confirmNewPasswordError = ""
        
        self.userService = Core.serviceLocator.getService(type: UserService.self)!
    }
    
    func setData(user: UserModel) {
        name = user.name
        lastName = user.lastName
        email = user.email
        phoneNumber = user.phoneNumber
    }
    
    func validateName() {
        nameError = name.isEmpty ? "Please enter your name" : ""
    }
    
    func validateLastName() {
        lastNameError = name.isEmpty ? "Please enter your last name" : ""
    }
    
    func validateEmail() {
        emailError = email.isValidEmail ? "" : "Please enter a valid email address" 
    }
    
    func validatePhoneNumber() {
        phoneNumberError = phoneNumber.isEmpty ? "Please enter your phone" : ""
    }
    
    func validateOldPassword() {
        oldPasswordError = oldPassword.isEmpty ? UserOperationError.invalidPassword.rawValue : ""
    }
    
    func validateNewPassword() {
        newPasswordError = newPassword.isEmpty ? UserOperationError.invalidPassword.rawValue : ""
    }
    
    func validateConfirmNewPassword() {
        if(confirmNewPassword.isEmpty || confirmNewPassword != newPassword) {
            confirmNewPasswordError = UserOperationError.invalidPassword.rawValue
        }
        else {
            confirmNewPasswordError = ""
        }
    }
    
    func isValid(checkPassword: Bool = false, checkOldPassword: Bool = false) -> Bool{
        let passwordCheck = (newPasswordError.isEmpty && confirmNewPasswordError.isEmpty) || !checkPassword
        let oldPasswordCheck = oldPasswordError.isEmpty || !checkOldPassword
        let basicForm = (nameError.isEmpty &&
                         lastNameError.isEmpty &&
                         emailError.isEmpty &&
                         phoneNumberError.isEmpty)
        
        
        return basicForm && passwordCheck && oldPasswordCheck
    }
}
