//
//  SplashViewModel.swift
//  LittleLemonFInalTask
//
//  Created by Amed on 5/20/24.
//

import Foundation

@MainActor
final class MainViewModel: ObservableObject {
    @Published var errorMsg = ""
    @Published var loading = true
    @Published var logged = false
    
    private let userService: UserService
    
    init() {
        self.userService = Core.serviceLocator.getService(type: UserService.self)!
    }
    
    func isUserLogged() async {
        do {
            logged = try userService.getUserLogged() != nil
            loading = false
        }
        catch {
            loading = false
            logged = false
            errorMsg = "Something bad happened"
            print(error)
        }
        
    }
}
