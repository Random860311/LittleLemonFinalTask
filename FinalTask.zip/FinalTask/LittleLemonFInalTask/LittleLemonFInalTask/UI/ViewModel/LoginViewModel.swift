//
//  LoginViewModel.swift
//  LittleLemonFInalTask
//
//  Created by Amed on 5/21/24.
//

import Foundation

@MainActor
final class LoginViewModel: ObservableObject {
    @Published var email = ""
    @Published var password = "" {
        didSet {
            validatePassword()
        }
    }
    
    @Published var emailError = ""
    @Published var passwordError = ""
    
    private let userService: UserService
    
    init() {
        self.userService = Core.serviceLocator.getService(type: UserService.self)!
    }
    
    func login() async -> Bool {
        do {
            validateEmail()
            validatePassword()
            
            return (emailError.isEmpty && passwordError.isEmpty) ? try userService.logginUser(email: email, password: password) != nil : false
        }
        catch UserOperationError.invalidPassword {
            emailError = UserOperationError.emailExists.rawValue
        }
        catch UserOperationError.invalidEmail {
            emailError = UserOperationError.invalidEmail.rawValue
        }
        catch UserOperationError.invalidCredentials {
            emailError = UserOperationError.invalidCredentials.rawValue
            passwordError = UserOperationError.invalidCredentials.rawValue
        }
        catch (let error) {
            print(error)
        }
        
        return false
    }
    
    func validateEmail() {
        emailError = email.isValidEmail ? "" : UserOperationError.invalidEmail.rawValue
    }
    
    func validatePassword() {
        passwordError = password.isEmpty ? UserOperationError.invalidPassword.rawValue : ""
    }
}
