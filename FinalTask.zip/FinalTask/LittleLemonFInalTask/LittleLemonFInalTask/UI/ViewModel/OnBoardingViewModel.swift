//
//  OnBoardingViewModel.swift
//  LittleLemonFInalTask
//
//  Created by Amed on 5/21/24.
//

import Foundation

@MainActor
final class OnBoardingViewModel: ObservableObject {
    @Published var userInfoViewModel = UserInfoViewModel()
    @Published var restaurant = RestaurantModel(id: UUID(), name: "", info: "", city: "", image: "")
    
    private let userService: UserService
    private let restaurantService: RestaurantService
    
    init() {
        self.userService = Core.serviceLocator.getService(type: UserService.self)!
        self.restaurantService = Core.serviceLocator.getService(type: RestaurantService.self)!
    }
    
    func loadRestaurantInfo() async {
        restaurant = restaurantService.getRestaurantData()
    }
    
    func register(checkOldPassword: Bool) async -> Bool {
        do {
            if(checkOldPassword) {
                let validOldPassword = try userService.checkCredentials(email: userInfoViewModel.email, password: userInfoViewModel.oldPassword)
                if(!validOldPassword) {
                    userInfoViewModel.emailError = UserOperationError.invalidCredentials.rawValue
                    userInfoViewModel.oldPassword = UserOperationError.invalidCredentials.rawValue
                    
                    return false
                }
            }
            _ = try userService.registerUser(
                name: userInfoViewModel.name,
                lastName: userInfoViewModel.lastName,
                email: userInfoViewModel.email,
                password: userInfoViewModel.newPassword,
                phoneNumber: userInfoViewModel.phoneNumber
            )
            return true
        }
        catch(let error) {
            print(error)
        }
        return false
    }
}
