//
//  ProfileViewModel.swift
//  LittleLemonFInalTask
//
//  Created by Amed on 5/26/24.
//

import Foundation

@MainActor
final class ProfileViewModel: ObservableObject {
    @Published var userInfoViewModel = UserInfoViewModel()
    
    @Published var configOrderStatus = false
    @Published var configPasswordChanges = false
    @Published var configSpecialOffers = false
    @Published var configNewsletter = false
    
    private let userService: UserService
    private var loggedUser: UserModel?
    
    init() {
        self.userService = Core.serviceLocator.getService(type: UserService.self)!
    }
    
    func loadLoggedUser() async {
        do {
            loggedUser = try userService.getUserLogged()
            if loggedUser == nil {
                return
            }
            
            userInfoViewModel.email = loggedUser!.email
            userInfoViewModel.oldPassword = loggedUser!.password
            userInfoViewModel.lastName = loggedUser!.lastName
            userInfoViewModel.name = loggedUser!.name
            userInfoViewModel.phoneNumber = loggedUser!.phoneNumber
            configNewsletter = loggedUser!.emailConfig.newsletter
            configOrderStatus = loggedUser!.emailConfig.orderStatus
            configPasswordChanges = loggedUser!.emailConfig.passwordChanges
            configSpecialOffers = loggedUser!.emailConfig.specialOffers
        }
        catch {
            print(error)
        }
    }
    
    func logOut() async -> Bool {
        do {
            try userService.logout()
            return true
        }
        catch {
            print(error)
        }
        return false
    }
    
    func saveChanges() async -> Bool {
        do {
            if loggedUser == nil {
                return false
            }
            let changePassword = !userInfoViewModel.newPassword.isEmpty
            
            var valid = userInfoViewModel.isValid(checkPassword: changePassword, checkOldPassword: false)

            if valid && loggedUser!.email != userInfoViewModel.email {
                valid = try userService.checkCredentials(email: userInfoViewModel.email, password: loggedUser!.password)
            }
        
            if valid {
                loggedUser!.name = userInfoViewModel.name
                loggedUser!.lastName = userInfoViewModel.lastName
                loggedUser!.password = changePassword ? userInfoViewModel.newPassword : loggedUser!.password
                loggedUser!.email = userInfoViewModel.email
                loggedUser!.phoneNumber = userInfoViewModel.phoneNumber
                loggedUser!.emailConfig.newsletter = configNewsletter
                loggedUser!.emailConfig.orderStatus = configOrderStatus
                loggedUser!.emailConfig.passwordChanges = configPasswordChanges
                loggedUser!.emailConfig.specialOffers = configSpecialOffers
                
                try userService.updateUser(loggedUser!)
                return true
            }
        }
        catch {
            print(error)
        }
        return false
    }
}
