//
//  DishService.swift
//  LittleLemonFInalTask
//
//  Created by Amed on 5/25/24.
//

import Foundation

protocol DishService {
    func insertDummyData() throws
    
    func getAll() throws -> [DishModel]
    func getAll(category: String) throws -> [DishModel]
    func getAllCategories() throws -> Set<String>
}
