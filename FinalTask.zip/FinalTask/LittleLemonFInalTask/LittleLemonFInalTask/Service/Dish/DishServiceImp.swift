//
//  DishServiceImp.swift
//  LittleLemonFInalTask
//
//  Created by Amed on 5/25/24.
//

import Foundation

final class DishServiceImp: BaseService, DishService {
    func insertDummyData() throws {
        let dishes = try getAll()
        if dishes.isEmpty {
            print("Inserting dummy dishes")
            let dishRepository = unitOfWork.dishRepository
            let models = mockData()
            _ = dishRepository.add(dishes: models)
            unitOfWork.saveChanges()
            print("Insert completed")
        }
    }
    
    
    func getAll(category: String) throws -> [DishModel] {
        let dishRepository = unitOfWork.dishRepository
        let result = dishRepository.getAll(category: category)
        switch result {
        case .success(let dishes):
            var models = [DishModel]()
            
            for dishEntity in dishes {
                models.append(dishEntity.toModel())
            }
            
            return models
        case .failure(let error):
            throw error
        }
    }
    
    func getAll() throws -> [DishModel] {
        let dishRepository = unitOfWork.dishRepository
        let result = dishRepository.getAll()
        switch result {
        case .success(let dishes):
            var models = [DishModel]()
            
            for dishEntity in dishes {
                models.append(dishEntity.toModel())
            }
            
            return models
        case .failure(let error):
            throw error
        }
    }
    
    func getAllCategories() throws -> Set<String> {
        let dishRepository = unitOfWork.dishRepository
        let result = dishRepository.getAllCategories()
        switch result {
        case .success(let categories):
            return categories
        case .failure(let error):
            throw error
        }
    }
    
    private func mockData() -> [DishModel] {
        return [
            DishModel(
                id: UUID(),
                name: "Beef Wellington tart",
                info: "This easy new twist on the continental dish, beef Wellington, turns the classic roulade shape into a tart. You can prep the flaky pastry weeks in advance, if you need to, and pop it out of the freezer to cook ahead of a dinner party!",
                category: "Starters",
                price: 21.20,
                img: "beef-wellington-tart-173822-1"
            ),
            DishModel(
                id: UUID(),
                name: "Tuna empanadillas",
                info: "Make these as a snack, a starter or a lunchbox filler - either way, they're easy, light and made from ingredients you probably have lying around.",
                category: "Starters",
                price: 19.20,
                img: "tastemagazine2108210427-mediterranean-pastry-172763-1"
            ),
            DishModel(
                id: UUID(),
                name: "Sweet fried saganaki",
                info: "Crispy, sweet and melt-in-your-mouth, we think you're going to fall in love with this Greek cheese. Serve it as a starter at your next dinner party or as a side at a summer BBQ.",
                category: "Starters",
                price: 18.15,
                img: "sweet-saganaki_digi_1980x1320-172761-1"
            ),
            DishModel(
                id: UUID(),
                name: "Bacon rings",
                info: "If you like it put a ring on it! Celebrate Bacon Week with these Hawaiian hoops!",
                category: "Starters",
                price: 9.15,
                img: "bacon-rings-103588-1"
            ),
            DishModel(
                id: UUID(),
                name: "Chilli con carne",
                info: "This great chilli recipe has to be one of the best dishes to serve to friends for a casual get-together. An easy sharing favourite that uses up storecupboard ingredients.",
                category: "Mains",
                price: 9.15,
                img: "recipe-image-legacy-id-1001451_6-c8d72b8"
            ),
            DishModel(
                id: UUID(),
                name: "Spaghetti bolognese",
                info: "Our best ever spaghetti bolognese is super easy and a true Italian classic with a meaty, chilli sauce. This pasta bolognese recipe is sure to become a family favourite.",
                category: "Mains",
                price: 19.15,
                img: "3bc1208e7a20c38eba142fc1478c3b3407c76f40"
            ),
            DishModel(
                id: UUID(),
                name: "Toad-in-the-hole",
                info: "Serve this comforting classic made with chipolata sausages and a simple batter – it’s easy enough that kids can help make it.",
                category: "Mains",
                price: 21.50,
                img: "289555fe39857aa4a97a4cc55af0c18501903421"
            ),
            DishModel(
                id: UUID(),
                name: "Cottage pie",
                info: "Make our classic meat and potato pie for a comforting dinner. This great-value family favourite freezes beautifully and is a guaranteed crowd-pleaser.",
                category: "Mains",
                price: 17.85,
                img: "recipe-image-legacy-id-1074465_10-0f090a9"
            ),
            DishModel(
                id: UUID(),
                name: "Easy fish pie",
                info: "A simple fish pie recipe that’s quick and easy to prepare. Portion into ramekins and freeze for quick toddler meals or cook in a big dish for the perfect family supper.",
                category: "Mains",
                price: 22.32,
                img: "recipe-image-legacy-id-1110455_10-bf7460d"
            ),
            DishModel(
                id: UUID(),
                name: "PIE",
                info: "Pie earns a spot on the top of everyone’s list of popular desserts merely for its delicious versatility.",
                category: "Deserts",
                price: 7.32,
                img: "pie-phpQ2kyfw"
            ),
            DishModel(
                id: UUID(),
                name: "COBBLERS AND CRUMBLES",
                info: "Cobblers and crumbles are a popular dessert that mix sweet and tart in equal measure.",
                category: "Deserts",
                price: 9.50,
                img: "cobbler-phpZyRmdx"
            ),
            DishModel(
                id: UUID(),
                name: "CHEESECAKE",
                info: "The cheesecake base is also great for combining with other sweet treats like brownies and pies for extra richness. While it may seem like a very contemporary dessert, the first cheesecake varieties were created as early as the 5th century B.C. on the Greek island of Samos, where a dessert was created from cheese, honey and nuts.",
                category: "Deserts",
                price: 11.99,
                img: "cheesecake-phpiHRUZJ"
            ),
            DishModel(
                id: UUID(),
                name: "BANANA PUDDING",
                info: "One of the South’s most popular dessert offerings, this layered mix of sweet banana pudding, fresh bananas, Nilla wafer cookies and whipped cream is a fluffy and creamy delight fresh from the icebox.",
                category: "Deserts",
                price: 4.99,
                img: "banana-pudding-phpzDIdZs"
            ),
            DishModel(
                id: UUID(),
                name: "CAKES AND CUPCAKES",
                info: "Cakes are one of America’s most revered confections — from the everyday to special occasions like birthdays and weddings, you will always find cake. They are also one of the most customizable popular desserts, as they're able to be shaped into spaceships, flowers and even objects that look too real to be dessert.",
                category: "Deserts",
                price: 7.89,
                img: "cake-php1625rU"
            ),
            DishModel(
                id: UUID(),
                name: "Margarita",
                info: "A margarita is a cocktail consisting of tequila, triple sec, and lime juice. Some margarita recipes include simple syrup as well and are often served with salt on the rim of the glass. Margaritas can be served either shaken with ice, without ice, or blended with ice.",
                category: "Drinks",
                price: 17.89,
                img: "Frozen-Margarita-1500x1500-hero-191e49b3ab4f4781b93f3cfacac25136"
            ),
            DishModel(
                id: UUID(),
                name: "Negroni",
                info: "The negroni is a cocktail, made of equal parts gin, vermouth rosso, and Campari, generally served on the rocks, and commonly garnished with an orange slice or orange peel. It is considered an apéritif.",
                category: "Drinks",
                price: 15.39,
                img: "negroni-720x720-primary-535dee7b50914af1810b1927b69dbe46"
            ),
        ]
    }
}
