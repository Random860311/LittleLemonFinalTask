//
//  BaseService.swift
//  LittleLemonFInalTask
//
//  Created by Amed on 5/26/24.
//

import Foundation

class BaseService {
    let unitOfWork: UnitOfWork
    
    init(unitOfWork: UnitOfWork) {
        self.unitOfWork = unitOfWork
    }
}
