//
//  RestaurantService.swift
//  LittleLemonFInalTask
//
//  Created by Amed on 5/25/24.
//

import Foundation
protocol RestaurantService {
    func getRestaurantData() -> RestaurantModel
}
