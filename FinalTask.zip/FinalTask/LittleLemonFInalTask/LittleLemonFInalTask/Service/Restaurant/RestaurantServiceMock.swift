//
//  RestaurantServiceMock.swift
//  LittleLemonFInalTask
//
//  Created by Amed on 5/25/24.
//

import Foundation
final class RestaurantServiceMock: RestaurantService {

    func getRestaurantData() -> RestaurantModel {
        let mockRestaurantData = RestaurantModel(
            id: UUID(),
            name: "Little Lemon",
            info: "We are a family owned Mediterranean restaurant, focused on tradicional recipes served with a modern twist.",
            city: "Chicago",
            image: ""
        )
        return mockRestaurantData
    }
    
    
}
