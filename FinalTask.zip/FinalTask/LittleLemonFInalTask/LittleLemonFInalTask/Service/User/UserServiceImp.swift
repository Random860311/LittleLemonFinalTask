//
//  UserServiceImp.swift
//  LittleLemonFInalTask
//
//  Created by Amed on 5/19/24.
//

import Foundation
final class UserServiceImp: BaseService, UserService {
    
    private func validateUser(existing user: UserModel) throws {
        try validateUser(name: user.name, lastName: user.lastName, email: user.email, password: user.password, checkEmail: false)
    }
    
    private func validateUser(name: String?, lastName: String?, email: String?, password: String?, checkEmail: Bool = true) throws {
        if email != nil {
            if !email!.isValidEmail {
                throw UserOperationError.invalidEmail
            }
            if checkEmail {
                let result = unitOfWork.userRepository.with(email: email!)
                switch result {
                case .success(let existingUser):
                    if existingUser != nil {
                        throw UserOperationError.emailExists
                    }
                case .failure(let error):
                    throw error
                }
            }
        }
        if name != nil && name!.isEmpty {
            throw UserOperationError.invalidName
        }
        if lastName != nil && lastName!.isEmpty {
            throw UserOperationError.invalidLastName
        }
        if password != nil && password!.isEmpty {
            throw UserOperationError.invalidPassword
        }
    }
    
    func registerUser(name: String, lastName: String, email: String, password: String, phoneNumber: String) throws -> UserModel {
        try validateUser(name: name, lastName: lastName, email: email, password: password)
        let result = unitOfWork.userRepository.registerUser(
            name: name,
            lastName: lastName,
            email: email,
            password: password,
            phoneNumber: phoneNumber
        )
        switch result {
        case.success(let userEntity):
            unitOfWork.saveChanges()
            return userEntity.toModel()
        case .failure(let error):
            throw error
        }
    }
    
    func updateUser(_ user: UserModel) throws {
        try validateUser(existing: user)
        let result = unitOfWork.userRepository.with(id: user.id)
        
        switch result {
        case.success(let userEntity):
            userEntity?.from(model: user)
            unitOfWork.saveChanges()
        case .failure(let error):
            throw error
        }
    }
    
    func checkCredentials(email: String, password: String) throws -> Bool {
        try validateUser(name: nil, lastName: nil, email: email, password: password, checkEmail: false)
        let result = unitOfWork.userRepository.with(email: email)
        switch result {
        case.success(let userEntity):
            return userEntity?.password == password
        case .failure(let error):
            throw error
        }
    }
    
    func logginUser(email: String, password: String) throws -> UserModel? {
        try validateUser(name: nil, lastName: nil, email: email, password: password, checkEmail: false)
        let result = unitOfWork.userRepository.with(email: email)
        switch result {
        case.success(let userEntity):
            if userEntity?.password == password {
                userEntity?.logged = true
                unitOfWork.saveChanges()
                return userEntity?.toModel()
            }
            throw UserOperationError.invalidCredentials
        case .failure(let error):
            throw error
        }
    }
    
    func logout() throws {
        let result = unitOfWork.userRepository.getLogged()
        switch result {
        case.success(let userEntity):
            userEntity?.logged = false
            unitOfWork.saveChanges()
        case .failure(let error):
            throw error
        }
    }
    
    func getUserLogged() throws -> UserModel? {
        let result = unitOfWork.userRepository.getLogged()
        switch result {
        case.success(let userEntity):
            return userEntity?.toModel()
        case .failure(let error):
            throw error
        }
    }
    
    
}
