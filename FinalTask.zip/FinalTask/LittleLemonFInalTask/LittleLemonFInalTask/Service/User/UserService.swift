//
//  UserService.swift
//  LittleLemonFInalTask
//
//  Created by Amed on 5/19/24.
//

import Foundation

enum UserOperationError: String, Error {
    case invalidPassword = "Password is invalid"
    case invalidEmail = "Email address is invalid"
    case invalidName = "Name is invalid"
    case invalidLastName = "Last name is invalid"
    case emailExists = "Email already in use"
    case invalidCredentials = "Invalid credentials"
}

protocol UserService: AnyObject {
    func getUserLogged() throws -> UserModel?
    func registerUser(name: String, lastName: String, email: String, password: String, phoneNumber: String) throws -> UserModel
    func checkCredentials(email: String, password: String) throws -> Bool
    func updateUser(_ user: UserModel) throws
    func logginUser(email: String, password: String) throws -> UserModel?
    func logout() throws
}

