//
//  CoreDataRepository.swift
//  EntitiesContextRelationships
//
//  Created by Amed on 4/13/24.
//

import Foundation
import CoreData

enum CoreDataError: Error {
    case invalidManagedObjectType
    case invalidPersistentStoreCoordinator
}

class CoreDataGenericRepository<T: NSManagedObject>: Repository {
    typealias Entity = T
    
    private let managedObjectContext: NSManagedObjectContext
    
    init(managedObjectContext: NSManagedObjectContext) {
        self.managedObjectContext = managedObjectContext
    }
    
    func get(predicate: NSPredicate?, sortDescriptors: [NSSortDescriptor]?, fetchLimit: Int) -> Result<[T], Error> {
        return fetchData(predicate: predicate, sortDescriptors: sortDescriptors, fetchLimit: fetchLimit, fetchBatchSize: nil, fetchOffset: nil)
    }
    
    func get(predicate: NSPredicate?, sortDescriptors: [NSSortDescriptor]?, fetchLimit: Int, fetchBatchSize: Int, fetchOffset: Int) -> Result<[T], Error> {
        return fetchData(predicate: predicate, sortDescriptors: sortDescriptors, fetchLimit: fetchLimit, fetchBatchSize: fetchBatchSize, fetchOffset: fetchOffset)
    }
    
    func get(predicate: NSPredicate?, sortDescriptors: [NSSortDescriptor]?) -> Result<[T], Error> {
        return fetchData(predicate: predicate, sortDescriptors: sortDescriptors, fetchLimit: nil, fetchBatchSize: nil, fetchOffset: nil)
    }
    
    func create() -> Result<T, Error> {
        let className = String(describing: T.self)
        guard let managedObject = NSEntityDescription.insertNewObject(forEntityName: className, into: managedObjectContext) as? T else {
            return .failure(CoreDataError.invalidManagedObjectType)
        }
        return .success(managedObject)
    }
    
    func delete(entity: T) -> Result<Bool, Error> {
        managedObjectContext.delete(entity)
        
        return .success(true)
    }
    
    func delete(predicate: NSPredicate?) -> Result<Bool, Error> {
        do {
            let className = String(describing: T.self)
            let fetchRequest: NSFetchRequest<NSFetchRequestResult> = NSFetchRequest(entityName: className)
            if let predicate = predicate {
                fetchRequest.predicate = predicate
            }
            let deleteRequest = NSBatchDeleteRequest(fetchRequest: fetchRequest)
            
            guard let persistentStoreCoordinator = managedObjectContext.persistentStoreCoordinator else {
                return .failure(CoreDataError.invalidPersistentStoreCoordinator)
            }
        
            try persistentStoreCoordinator.execute(deleteRequest, with: managedObjectContext)
        } catch {
            return .failure(error)
        }
        return .success(true)
    }
    
    private func fetchData(predicate: NSPredicate?, sortDescriptors: [NSSortDescriptor]?, fetchLimit: Int?, fetchBatchSize: Int?, fetchOffset: Int?) -> Result<[Entity], Error> {
        let fetchRequest = T.fetchRequest()
        fetchRequest.predicate = predicate
        fetchRequest.sortDescriptors = sortDescriptors
        
        if let fetchLimit = fetchLimit {
            fetchRequest.fetchLimit = fetchLimit
        }
        
        if let fetchBatchSize = fetchBatchSize {
            fetchRequest.fetchBatchSize = fetchBatchSize
        }
        
        if let fetchOffset = fetchOffset {
            fetchRequest.fetchOffset = fetchOffset
        }
        
        do {
            if let fetchResult = try managedObjectContext.fetch(fetchRequest) as? [T] {
                return .success(fetchResult)
            }
            return .failure(CoreDataError.invalidManagedObjectType)
        } catch {
            return .failure(error)
        }
    }
}
