//
//  Repository.swift
//  EntitiesContextRelationships
//
//  Created by Amed on 4/13/24.
//

import Foundation
import CoreData

protocol Repository<Entity> {
    associatedtype Entity where Entity: NSManagedObject
    
    func get(predicate: NSPredicate?, sortDescriptors: [NSSortDescriptor]?, fetchLimit: Int, fetchBatchSize: Int, fetchOffset: Int) -> Result<[Entity], Error>
    func get(predicate: NSPredicate?, sortDescriptors: [NSSortDescriptor]?, fetchLimit: Int) -> Result<[Entity], Error>
    func get(predicate: NSPredicate?, sortDescriptors: [NSSortDescriptor]?) -> Result<[Entity], Error>
    
    func create() -> Result<Entity, Error>
    
    func delete(entity: Entity) -> Result<Bool, Error>
    
    func delete(predicate: NSPredicate?) -> Result<Bool, Error>
}
