//
//  BaseRepository.swift
//  EntitiesContextRelationships
//
//  Created by Amed on 4/13/24.
//

import Foundation
import CoreData

class BaseRepository<Entity: NSManagedObject> {
    let delegate: any Repository<Entity>
    
    init(managedObjectContext: NSManagedObjectContext) {
        self.delegate = CoreDataGenericRepository<Entity>(managedObjectContext: managedObjectContext)
    }
}
