//
//  DishRepositoryImp.swift
//  LittleLemonFInalTask
//
//  Created by Amed on 5/26/24.
//

import Foundation

final class DishRepositoryImp: BaseRepository<DishEntity>, DishRepository {
    func getAll(category: String) -> Result<[DishEntity], Error> {
        let predicate = NSPredicate(format: "category == %@", category)
        return delegate.get(predicate: predicate, sortDescriptors: nil)
    }
    
    func getAll() -> Result<[DishEntity], Error> {
        return delegate.get(predicate: NSPredicate(value: true), sortDescriptors: nil)
    }
    
    func getAllCategories() -> Result<Set<String>, Error> {
        let result = getAll()
        switch result {
        case .success(let dishes):
            var categories: Set<String> = []
            dishes.forEach{ dish in
                categories.insert(dish.category)
            }
            return .success(categories)
        case .failure(let error):
            return .failure(error)
        }
    }
    
    func add(dishes: [DishModel]) -> Result<[DishEntity], Error> {
        var dishEntities = [DishEntity]()
        for dishModel in dishes {
            let result = delegate.create()
            switch result{
            case .success(let dishEntity):
                dishEntity.from(model: dishModel)
                dishEntities.append(dishEntity)
            case .failure(let error):
                return .failure(error)
            }
        }
        return .success(dishEntities)
    }
    
}
