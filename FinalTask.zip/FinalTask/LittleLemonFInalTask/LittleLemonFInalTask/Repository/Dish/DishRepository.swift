//
//  DishRepository.swift
//  LittleLemonFInalTask
//
//  Created by Amed on 5/25/24.
//

import Foundation

protocol DishRepository {
    func getAll() -> Result<[DishEntity], Error>
    func getAll(category: String) -> Result<[DishEntity], Error>
    func getAllCategories() -> Result<Set<String>, Error>
    func add(dishes: [DishModel]) -> Result<[DishEntity], Error>

}
