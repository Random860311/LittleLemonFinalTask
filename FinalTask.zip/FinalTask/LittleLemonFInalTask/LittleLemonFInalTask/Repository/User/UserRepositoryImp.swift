//
//  CustomerCoreDataRepository.swift
//  EntitiesContextRelationships
//
//  Created by Amed on 4/13/24.
//

import Foundation
import CoreData

final class UserRepositoryImp: BaseRepository<UserEntity>, UserRepository {
       
    func registerUser(name: String, lastName: String, email: String, password: String, phoneNumber: String) -> Result<UserEntity, Error> {
        let result = delegate.create()
        switch result {
        case .success(let user):
            user.id = UUID()
            user.email = email
            user.logged = true
            user.name = name
            user.lastName = lastName
            user.password = password
            user.phone = phoneNumber
            
            return .success(user)
        case .failure(let error):
            return .failure(error)
        }
    }
    
    func getLogged() -> Result<UserEntity?, Error> {
        let predicate = NSPredicate(format: "logged == YES")
        
        let result = delegate.get(predicate: predicate, sortDescriptors: nil, fetchLimit: 1)
        
        switch result {
        case .success(let entities):
            return .success(entities.first)
        case .failure(let error):
            return .failure(error)
        }
    }
    
    func delete(name: String) -> Result<Bool, Error> {
        let predicate = NSPredicate(format: "name == %@", name)
        
        return delegate.delete(predicate: predicate)
    }
    
    func with(email: String) -> Result<UserEntity?, Error> {
        let predicate = NSPredicate(format: "email == %@", email)
        
        let result = delegate.get(predicate: predicate, sortDescriptors: nil, fetchLimit: 1)
        
        switch result {
        case .success(let entities):
            return .success(entities.first)
        case .failure(let error):
            return .failure(error)
        }
    }

    
    func with(name: String) -> Result<[UserEntity], Error> {
        let predicate = NSPredicate(format: "name == %@", name)
        
        let result = delegate.get(predicate: predicate, sortDescriptors: nil)
        
        switch result {
        case .success(let entities):
            return .success(entities)
        case .failure(let error):
            return .failure(error)
        }
    }
    
    func with(id: UUID) -> Result<UserEntity?, Error> {
        let predicate = NSPredicate(format: "id == %@", id as CVarArg)
        
        let result = delegate.get(predicate: predicate, sortDescriptors: nil, fetchLimit: 1)
        
        switch result {
        case .success(let entities):
            return .success(entities.first)
        case .failure(let error):
            return .failure(error)
        }
    }
}
