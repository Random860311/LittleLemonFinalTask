//
//  CustomerRepository.swift
//  EntitiesContextRelationships
//
//  Created by Amed on 4/13/24.
//

import Foundation

protocol UserRepository {
    func getLogged() -> Result<UserEntity?, Error>
    
    func with(email: String) -> Result<UserEntity?, Error>
    func with(id: UUID) -> Result<UserEntity?, Error>
    func with(name: String) -> Result<[UserEntity], Error>
    
    func delete(name: String) -> Result<Bool, Error>
    
    func registerUser(name: String, lastName: String, email: String, password: String, phoneNumber: String) -> Result<UserEntity, Error>
}
