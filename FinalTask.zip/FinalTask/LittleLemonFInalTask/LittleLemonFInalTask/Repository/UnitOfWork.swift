//
//  UnitOfWork.swift
//  EntitiesContextRelationships
//
//  Created by Amed on 4/13/24.
//

import Foundation
import CoreData

final class UnitOfWork {
    private let context: NSManagedObjectContext
    
    let userRepository: any UserRepository
    let dishRepository: any DishRepository
    
    init(context: NSManagedObjectContext) {
        self.context = context
        
        self.userRepository = UserRepositoryImp(managedObjectContext: context)
        self.dishRepository = DishRepositoryImp(managedObjectContext: context)
    }
    
    @discardableResult
    func saveChanges() -> Result<Bool, Error> {
        guard context.hasChanges else { return .success(true) }
        do {
            try context.save()
            return .success(true)
        }
        catch {
            context.rollback()
            return .failure(error)
        }
    }
}
